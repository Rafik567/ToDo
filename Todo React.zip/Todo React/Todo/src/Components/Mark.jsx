import React from 'react'
import Testing from './Testing'
const Mark = () => {
     
    return (
        <>
            <div>
                <div className='bg-white-500 w-[300px] h-[100px] rounded-[20px] shadow-lg shadow-white-500/50'>
                    <b className='text-[30px] flex justify-center' >Mark Complate</b>
                </div>
            </div>
            
        </>
            )
            
            
}

export default Mark