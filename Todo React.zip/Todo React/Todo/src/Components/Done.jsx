import React from 'react'

const Done = () => {
    return (
        <div>
            <div className='bg-white-500 w-[300px] h-[100px] rounded-[20px] shadow-lg shadow-white-500/50'>
                <b className='text-[30px] flex justify-center' >Done</b>
            </div>

        </div>
    )
}

export default Done