import React, { useState } from 'react';

const Testing = () => {
    const [newTodo, setNewTodo] = useState("");
    const [todos, setTodos] = useState([]);   
    const addTodo = () => {
        if (newTodo.trim() === "") return; 
        setTodos([...todos, { text: newTodo, id: Date.now(), completed: false }]);
        setNewTodo(""); 
    };
        // const storage = () => {
        //   if( localStorage.setItem("text",test)){   
                
        //   } 
        // }

  



    return (
        <div>
            <div className='bg-white-500 w-[300px]  rounded-[20px] shadow-lg shadow-white-500/50'>
                <b className='text-[30px] flex justify-center'>Todo</b>
                <div className='flex gap-[10px]'>
                    <input
                        type="text"
                        value={newTodo}
                        onChange={(e) => setNewTodo(e.target.value)}
                        placeholder="Enter a new task"
                        className='bg-gray-400 w-[200px] rounded-[10px]'
                    />
                    <button className='bg-blue-400 w-[100px] rounded-[10px]' onClick={addTodo}>Add Todo</button>
                </div>
                <ul>
                    {todos.map((todo) => (
                        <li key={todo.id}>
                            <div className='flex  gap-[20px]'>
                                <span>{todo.text}</span>
                                <button className='bg-blue-400 w-[110px] rounded-[10px]' onClick={ storage}>Mark Complate</button>
                            </div>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}

export default Testing;
