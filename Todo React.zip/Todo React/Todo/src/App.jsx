import { useState } from 'react'
import './App.css'
import Testing from './Components/Testing'
import Mark from './Components/Mark'
import Done from './Components/Done'

function App() {
  return (
    
    <>
    
      <div className='flex  justify-center  gap-[100px] mt-[350px]'> 
        <Testing />
        <Mark />
        <Done/>
      </div>
    </>
  )
}

export default App
